러비러비톡 상세 화면 추가 스킨
모든 PNG는 RGBA. 기존 community_skin의 frame_outer, background_optional, icon_like, icon_comment, icon_more 재사용.
frame_mobile: 원본 시안의 외곽을 마스킹한 추출본 (일부 배경 발광 잔존 가능).
icon_back, icon_send, icon_profile_rabbit, icon_like_active, divider_detail: 원본에서 추출, 작은 해상도 및 발광 잔존 가능.
panel_* 및 button_*: 시안 기반 재구성한 빈 패널, 원본 픽셀과 동일하지 않음. 버튼 글자/숫자는 코드로 표시.
패널은 9-slice 권장 (모서리 32px, 버튼 24px부터 실제 렌더 확인). 프레임은 상하 중앙 장식 보존 필요.
공유/북마크/이미지 댓글 등 미확정 기능 추가 없음.
